package com.Serialization_And_Deserilization;

import java.io.Serializable;

// if not implements Serializabe class  the it will prevent us to convert into byte steram
public class Student implements Serializable{

	 int stuRollNO;
	 String studentName;

	 //private final we can deseriliaze
	 // but static we cannot bcz selerilization belongs to object not class 
	 
	 // to skip the field - we can comment or we can use transient keyword to skip the filed

     //serilizable interface there we have 0 methods 
	 
	 //Externalization - interface
	 //we have two Unimplemented methods
	 
}
