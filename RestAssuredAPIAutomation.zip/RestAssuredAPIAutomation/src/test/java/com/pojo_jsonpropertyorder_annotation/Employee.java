package com.pojo_jsonpropertyorder_annotation;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/* we have chosed explicitly field of sequence in this order {"fName","lName","address"} 
at the time of serialization and deserialization this order will be in usecase

Note : if in case the nested pojo classes need to add order for each nested 
pojo class separately

USE : used to maintain the order of the fields explicitly as we required
 */

@JsonPropertyOrder({"fName","lName","address"})
public class Employee {
	
/* Note : default order of the fields same as we declared fields one after another
	this is the below is default order of the fields
*/
	private String lName;
	private String fName;
	private Address address;
	
	
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
}
