package com.getrequest;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class Get_03 {

	 RestAssuredConfig config = RestAssured.config()
             .sslConfig(new SSLConfig().allowAllHostnames().relaxedHTTPSValidation());
	
	@Test
	public void getReq_01() {
		
		 // https://restful-booker.herokuapp.com/booking
		 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		 
		  specBuilder.setBaseUri("https://reqres.in").setBasePath("/api/users").addQueryParam("page", "2");
     
		  RequestSpecification reqBuild = specBuilder.build();
		   
	String response = RestAssured.
		             given()
		            .spec(reqBuild)
		            .config(config)
		            .when()
		            .get()
		            .then()
		            .log()
		            .all()
		            .extract()
		            .response()
		            .asString();
		 
	
	 System.err.println("Response asString  :"+response);
	
	
	}
	@Test
		public void getReq_02() {
		
			 // https://restful-booker.herokuapp.com/booking
			 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
			 
			  specBuilder.setBaseUri("https://reqres.in").setBasePath("/api/users").addQueryParam("page", "2");
	     
			  RequestSpecification reqBuild = specBuilder.build();
			   
		String response = RestAssured.
			             given()
			            .spec(reqBuild)
			            .config(config)
			            .when()
			            .get()
			            .then()
			            .log()
			            .all()
			            .extract()
			            .response()
			            .asPrettyString();
			 
		
		 System.err.println("Response asPrettyString  :"+response);
		
		
		}
}
