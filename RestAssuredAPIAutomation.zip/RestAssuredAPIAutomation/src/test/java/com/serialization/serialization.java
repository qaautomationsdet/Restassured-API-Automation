package com.serialization;
import org.junit.Assert;
import org.testng.annotations.Test;

import com.deserlization.Deseralize;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class serialization {
	 RestAssuredConfig config = RestAssured.config()
             .sslConfig(new SSLConfig().allowAllHostnames().relaxedHTTPSValidation());
	 
     	@Test
		public void seri() {
				
	  /*	
	   {
		    "name": "morpheus",
		    "job": "leader"
		}
      */
		
		Person person = new Person();
		person.setName("jhon");
		person.setJob("qa");

		ObjectMapper objmapper = new ObjectMapper();
	
		String payload = null;
		try {	//serialize :converting java class object into byte stream
			payload = objmapper.writerWithDefaultPrettyPrinter().writeValueAsString(person);
		} catch (JsonProcessingException e) {
		
			e.printStackTrace();
		}
		
		
		RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		
		specBuilder.setBaseUri("https://reqres.in");
		specBuilder.setBasePath("/api/users");
		specBuilder.setBody(payload);
		specBuilder.setContentType(ContentType.JSON);	
		RequestSpecification reqSecification = specBuilder.build();
		
					Response response = RestAssured.given()
												           .spec(reqSecification)
												           .config(config)
												           .log()
												           .all()
												           .when()
												           .post();
		
		 ValidatableResponse validatableRes = response.then();
		       
		            String extractRes = validatableRes.log()
		                                              .all()
		                                              .extract()
		                                              .response()
		                                              .asString();


	}
	
}
