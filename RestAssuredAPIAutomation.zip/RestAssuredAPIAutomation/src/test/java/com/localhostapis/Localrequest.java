package com.localhostapis;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.specification.RequestSpecification;

public class Localrequest {
	
		//@Test
		public void getReq_01() {

		 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
			 
	     specBuilder.setBaseUri("http://localhost:3000/posts");
		  RequestSpecification reqBuild = specBuilder.build();
		   
		 RestAssured.
		             given()
		            .spec(reqBuild)
		            .when()
		            .get()
		            .then()
		            .log()
		            .all()
		            .extract()
		            .response()
		            .asPrettyString();
			
		}
		@Test
		public void getReq_02() throws IOException {
			byte[] bytePayload = Files.readAllBytes(Paths.get("C:\\Users\\pmali3\\eclipse-workspace\\RApi-f-copy2\\src\\test\\resources\\jsonfiles\\data.json"));

			String payload= new String(bytePayload);
		 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
			 
	      specBuilder.setBaseUri("http://localhost:3000/posts")
	      .setBody(payload);
		  RequestSpecification reqBuild = specBuilder.build();
		   
		  
		  
		 RestAssured.
		             given()
		            .spec(reqBuild)
		            .when()
		            .post()
		            .then()
		            .log()
		            .all()
		            .extract()
		            .response()
		            .asPrettyString();
			
		}
		
	}

