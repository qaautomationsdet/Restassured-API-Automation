package com.xmlpath;
import java.util.List;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class XmlPathResponse {

	RestAssuredConfig config = RestAssured.config()
            .sslConfig(new SSLConfig().allowAllHostnames().relaxedHTTPSValidation());

	@Test
	public void xmlResponse() {
		
		//http://restapi.adequateshop.com/api/Traveler
	
		 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
			 
		 specBuilder.setBaseUri("http://restapi.adequateshop.com").
		 setBasePath("/api/Traveler").
		 addQueryParam("page","1")
		.setContentType(ContentType.XML)
		.setConfig(config);
		 
		  RequestSpecification reqBuild = specBuilder.build();
		   
					 Response response = RestAssured.
										             given()
										            .spec(reqBuild)
										            .log()
										            .all()
										            .when()
										            .get();
	   ValidatableResponse validatbleRes = response .then();
								            								            		 
		        String extarctRes = validatbleRes   .log()
										            .all()
										            .extract()
										            .response()
										            .asPrettyString();
						            
		                              // validate the response
		                              validatbleRes.assertThat()
		                                            .statusCode(200)
		                                            .statusLine("HTTP/1.1 200 OK")
		                                           .contentType("application/xml; charset=utf-8");
		                                                                                     
		            XmlPath xmlPath = new XmlPath(extarctRes);
		    Object travlerID = xmlPath.get("TravelerinformationResponse.travelers.Travelerinformation[0].id");
		    System.out.println("ID "+travlerID);
		     
		    Object travlerIDs = xmlPath.get("TravelerinformationResponse.travelers.Travelerinformation");
		    System.out.println("IDs "+travlerID);
		    
		    Object pageno = xmlPath.get("TravelerinformationResponse.page");
		    System.out.println("pageNo "+pageno);
		    
		    Object Travelerinformation = xmlPath.get("TravelerinformationResponse.travelers.Travelerinformation[0]");
		    System.out.println("Travelerinformation[0]  "+ Travelerinformation.toString());
		
		     //Object travlers = xmlPath.get("TravelerinformationResponse.travelers");
		    List<Object> travlers = xmlPath.getList("TravelerinformationResponse.travelers.Travelerinformation");
		    System.out.println(travlers.size());    
	
		    List<Object> allids= xmlPath.getList("TravelerinformationResponse.travelers.Travelerinformation.id");
		    System.out.println(allids);

	}	
}
