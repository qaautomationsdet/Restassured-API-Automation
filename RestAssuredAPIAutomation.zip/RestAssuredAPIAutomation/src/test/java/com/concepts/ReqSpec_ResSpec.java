package com.concepts;
import org.hamcrest.Matchers;
import static org.hamcrest.Matcher.*;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class ReqSpec_ResSpec {
	@Test
		public void getReq_01() {
		
		  //for request inputs
		  RequestSpecBuilder reqSpecBuilder = new RequestSpecBuilder(); 
		  reqSpecBuilder
		  
		  .setBaseUri("https://reqres.in")
		  .setBasePath("/api/users")
		  .addQueryParam("page", 2);
		  
		  
		  RequestSpecification reqBuild = reqSpecBuilder.build();
		  
		  
		  //for response validation
		  ResponseSpecBuilder resSpecBuilder = new ResponseSpecBuilder();
		  ((ResponseSpecification) resSpecBuilder
				  
		  .expectStatusCode(200)
		  .expectContentType(ContentType.JSON))
		  .time(Matchers.lessThan(9000L)); //9 milisecond
		  
		  
		  ResponseSpecification resBuild = resSpecBuilder.build();
		  		  
		  RestAssured.
		             given()
		            .spec(reqBuild)
		            .when()
		            .get()
		            .then()
		            .spec(resBuild)
		            .log()
		            .all()
		            .extract()
		            .response()
		            .asPrettyString();
		 
}
		@Test
		public void getReq_02() {
		
         // for request inputs
		 RequestSpecification reqSpec = RestAssured.given();
		 
		 reqSpec.baseUri("https://reqres.in")
		        .basePath("/api/users")
		        .queryParam("page", 2);
		  
		 //for response validation
		 ResponseSpecification resSpec = RestAssured.expect();	
		 
		 resSpec .statusCode(200)
				  .contentType(ContentType.JSON)
				  .time(Matchers.greaterThan(3000L));
		  		  
		 RestAssured.
		             given()
		            .spec(reqSpec)
		            .when()
		            .get()
		            .then()
		            .spec(resSpec)
		            .log()
		            .all()
		            .extract()
		            .response()
		            .asPrettyString();
		 
		}
}
