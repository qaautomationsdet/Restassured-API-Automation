package com.pojo_jsonrootname_annotation;

import com.fasterxml.jackson.annotation.JsonRootName;

/* using this annotation we will change the root name explicitly
 in case we need different root name then this annotation came into picture
 
 Note : if we not specified root name explicitly then
 root class name act as default root-name 
 
 default- root name : Employee (class name)
*/
@JsonRootName(value = "Emp")
public class Employee {

	private String FName;
	private String LName;
	private String Address;
	private String Age;
	public String getFName() {
		return FName;
	}
	public void setFName(String fName) {
		FName = fName;
	}
	public String getLName() {
		return LName;
	}
	public void setLName(String lName) {
		LName = lName;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getAge() {
		return Age;
	}
	public void setAge(String age) {
		Age = age;
	}
	
}
