package com.dataprovider;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class DataProviderPayload {
	
	 RestAssuredConfig config = RestAssured.config()
             .sslConfig(new SSLConfig().allowAllHostnames().relaxedHTTPSValidation());

	     // generate values
		 @DataProvider(name = "bodyDataProvider")
			public Object[][]bodyValues(){
				
				return new Object[][]{
				 // name       // job
					{"abc1"  ,   "xyz1"},
					{"abc2"  ,   "xyz2"},
					{"abc3"  ,   "xyz3"},
					{"abc4"  ,   "xyz4"},
					
				};
			}

		// Request will be get executed 4 times for 4set of Data
		@Test(dataProvider ="bodyDataProvider")
		public void postReq_03(String name ,String job) throws IOException {		
			// java map	
			Map map = new LinkedHashMap();
			map.put("name", name);
			map.put("job", job);
		
		RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		
		specBuilder.setBaseUri("https://reqres.in").setBasePath("/api/users")
		.setBody(map)
		.setContentType(ContentType.JSON)
		.setConfig(config);
		
		RequestSpecification reqSecification = specBuilder.build();
		
		Response response = RestAssured.given()
									           .spec(reqSecification)
									           .log()
									           .all()
									           .when()
									           .post();
		
		ValidatableResponse validatableRes = response.then();
		       
		            String extractRes = validatableRes.log()
		                                              .all()
		                                              .extract()
		                                              .response()
		                                              .asString();
     
	}	
}
