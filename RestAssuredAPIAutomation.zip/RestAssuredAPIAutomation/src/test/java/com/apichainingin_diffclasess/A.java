package com.apichainingin_diffclasess;

public class A {

}
