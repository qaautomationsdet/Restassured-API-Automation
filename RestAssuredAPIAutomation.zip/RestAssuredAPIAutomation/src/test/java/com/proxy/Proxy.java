package com.proxy;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.ProxySpecification;
import io.restassured.specification.RequestSpecification;

public class Proxy {
	
	 RestAssuredConfig config = RestAssured.config()
            .sslConfig(new SSLConfig().allowAllHostnames().relaxedHTTPSValidation());

	@Test
	public void proxySettings() {
		
		 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		
		specBuilder.setBaseUri("https://reqres.in").setBasePath("/api/users").addQueryParam("page", "2");

		  RequestSpecification reqBuild = specBuilder.build();
		   
		  ProxySpecification spec = new ProxySpecification("proxy.host.com", 8080, "http");
		  
					 Response response = RestAssured.
										             given()
										             .proxy(spec)
										            .config(config)
										            .spec(reqBuild)
										            .log()
										            .all()
										            .when()
										            .get();
	   ValidatableResponse validatbleRes = response .then();
								            								            		 
		        String extarctRes = validatbleRes   .log()
										            .all()
										            .extract()
										            .response()
										            .asPrettyString();
						            
		                              validatbleRes.assertThat()
		                                            .statusCode(200)
		                                            .statusLine("HTTP/1.1 200 OK");
		                                                                                     
		               JsonPath jsonPath = new JsonPath(extarctRes);  
		               Object pageNo = jsonPath.get("per_page");
		               System.out.println("total_pages :"+ pageNo);
		           
	}
}
