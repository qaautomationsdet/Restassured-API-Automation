package com.apichaininginsameclass;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class ApiChaining {
int id ; //global 
	
RestAssuredConfig config = RestAssured.config()
.sslConfig(new SSLConfig().allowAllHostnames().relaxedHTTPSValidation());

	//  create user - post
	@Test(priority = 0)
	public void createUser() {
		
		System.out.println("********** POST REQUEST *************");

	    // Faker is depedency required in POM.xml we can ganrate automatic dummy data for testing using diff methods
		Faker faker = new Faker();	
		
		// for this JSONObject class required // json-simple // dependency in POM.xml
		JSONObject payload = new JSONObject();
		
		
		payload.put("name",faker.name().fullName());
		payload.put("gender","male");
		payload.put("email",faker.internet().emailAddress());
		payload.put("status","active");
		
		String bearerToken = "Bearer "+"4488a6386727c443b96ef8c05aa44c1049589de7de1e71f2a3787544696d1bb7";
		

		RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		
		specBuilder.setBaseUri("https://gorest.co.in")
		           .setBasePath("/public/v2/users")
		           .addHeader("Authorization",bearerToken)
		           .setContentType(ContentType.JSON)
		           .setBody(payload.toJSONString())
		           .setConfig(config);
		
		RequestSpecification requestBuild = specBuilder.build();
		
									     Response reponse = RestAssured.given()
												           .spec(requestBuild)
												           .log()
												           .all()
												           .when()
												           .post();
									                        
          ValidatableResponse validatableResponse = reponse.then();
                 
                  String responseBody = validatableResponse.log()
												           .all()
												           .extract()
												           .response()
												           .asPrettyString();
												
                                        // validation expeceted status code
                                        validatableResponse.statusCode(201);
                                                       
                 JsonPath jsonPath = new JsonPath(responseBody);                      
                                        
                 int userid = jsonPath.get("id");
                 System.out.println("id  : "+ userid);
                 
                 id = userid;
                 // 
                 
	}

	// getuser - get	
	@Test(priority = 1)
	public void GetUser() {
		
		System.out.println("********** GET REQUEST *************");
		
RequestSpecBuilder specBuilder = new RequestSpecBuilder();

String bearerToken = "Bearer "+"4488a6386727c443b96ef8c05aa44c1049589de7de1e71f2a3787544696d1bb7";

      //https://gorest.co.in/public/v2/users/id

		specBuilder.setBaseUri("https://gorest.co.in")
		           .setBasePath("/public/v2/users/"+id)
		           .addHeader("Authorization",bearerToken)
		           .setContentType(ContentType.JSON)
		           .setConfig(config);
				
		RequestSpecification requestBuild = specBuilder.build();
		
									     Response reponse = RestAssured.given()
												           .spec(requestBuild)
												           .log()
												           .all()
												           .when()
												           .get();
									                        
          ValidatableResponse validatableResponse = reponse.then();
                 
                  String responseBody = validatableResponse.log()
												           .all()
												           .extract()
												           .response()
												           .asPrettyString();
												
                                        // validation expeceted status code
                                        validatableResponse.statusCode(200);
                                                       
                  JsonPath jsonPath = new JsonPath(responseBody);       
	}

   //update user - put	
    @Test(priority = 2)
	public void updateUser() {
		
    	System.out.println("********** PUT REQUEST *************");

	    // Faker is depedency required inPOM.xml we can gerenate automatic data using diff methods
		Faker faker = new Faker();
			
		
		// for this JSONObject class required // json-simple // dependency in POM.xml
		JSONObject payload = new JSONObject();
		payload.put("name",faker.name().fullName());
		payload.put("gender","female");
		payload.put("email",faker.internet().emailAddress());
		payload.put("status","inactive");
		
		String bearerToken = "Bearer "+"4488a6386727c443b96ef8c05aa44c1049589de7de1e71f2a3787544696d1bb7";
		

		RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		
		specBuilder.setBaseUri("https://gorest.co.in")
		           .setBasePath("/public/v2/users/"+id)
		           .addHeader("Authorization",bearerToken)
		           .setContentType(ContentType.JSON)
		           .setBody(payload.toJSONString())
		           .setConfig(config);
				
		RequestSpecification requestBuild = specBuilder.build();
		
									     Response reponse = RestAssured.given()
												           .spec(requestBuild)
												           .log()
												           .all()
												           .when()
												           .put();
									                        
          ValidatableResponse validatableResponse = reponse.then();
                 
                  String responseBody = validatableResponse.log()
												           .all()
												           .extract()
												           .response()
												           .asPrettyString();
												
                                        // validation expeceted status code
                                        validatableResponse.statusCode(200);
                                                       
                 
		
	}

	// deleteuser - delete	
	@Test(priority = 3)
	public void DeleteUser() {
		
		System.out.println("********** DELETE REQUEST *************");


		RequestSpecBuilder specBuilder = new RequestSpecBuilder();

		String bearerToken = "Bearer "+"4488a6386727c443b9c1049589de7de1e71f2a3787544696d1bb7";

		      //https://gorest.co.in/public/v2/users/id

				specBuilder.setBaseUri("https://gorest.co.in")
				           .setBasePath("/public/v2/users/"+id)
				           .addHeader("Authorization",bearerToken)
				           .setContentType(ContentType.JSON)
				           .setConfig(config);
				         
						JSONObject js = new JSONObject();
				RequestSpecification requestBuild = specBuilder.build();
				
											     Response reponse = RestAssured.given()
														           .spec(requestBuild)
														           .log()
														           .all()
														           .when()
														           .delete();
											                        
		          ValidatableResponse validatableResponse = reponse.then();
		                 
		                  String responseBody = validatableResponse.log()
														           .all()
														           .extract()
														           .response()
														           .asPrettyString();
														
		                                        // validation expeceted status code
		                                        validatableResponse.statusCode(204);
		                                                       
		                  JsonPath jsonPath = new JsonPath(responseBody);    
   
	}
	
}
