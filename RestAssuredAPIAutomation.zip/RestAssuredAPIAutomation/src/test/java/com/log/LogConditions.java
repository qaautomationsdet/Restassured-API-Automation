package com.log;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.response.ValidatableResponseLogSpec;
import io.restassured.specification.RequestSpecification;

public class LogConditions {
	
	 RestAssuredConfig config = RestAssured.config()
             .sslConfig(new SSLConfig().allowAllHostnames().relaxedHTTPSValidation());
		
	   //@Test
		public void getReq_01() {

		 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
			 
	     specBuilder.setBaseUri("https://reqres.in").setBasePath("/api/users").addQueryParam("page", "2");
		  RequestSpecification reqBuild = specBuilder.build();
		   
		 RestAssured.
		             given()
		            .config(config)
		            .spec(reqBuild)            
		            .when()
		            .get()
		            .then()
		            .log().ifValidationFails() /* Logs everything if a test validation fails*/
		            .extract()
		            .response()
		            .asPrettyString();
			
		}
	   // @Test
		public void getReq_02() {
	    	/* If you're only interested in printing the response body if an error occur then you can use:
	    	.log().ifError()
	    	make sure you are using .log().ifError() just after than otherwise logs will not show.
	    	It logs everything only if an error occurs (status code >= 400).  */
		
	    RequestSpecBuilder specBuilder = new RequestSpecBuilder();
			 
	     specBuilder.setBaseUri("https://reqres.in").setBasePath("/api/userss").addQueryParam("page", "2");
		 RequestSpecification reqBuild = specBuilder.build();
		   
		  RestAssured.
		             given()
		            .config(config)
		            .spec(reqBuild)  
		            .when()
		            .get()
		            .then()
		            .log().ifError() /* Logs everything only if an error occurs (status code >= 400).*/
		            .extract()
		            .response()
		            .asPrettyString();
	}
	    @Test
		public void getReq_03() {

		 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
			 
	     specBuilder.setBaseUri("https://reqres.in").setBasePath("/api/users").addQueryParam("page", "2");
		  RequestSpecification reqBuild = specBuilder.build();
		   
		 RestAssured.
		             given()
		             .config(config)
		            .spec(reqBuild)
		            .when()
		            .get()
		            .then()
		            
		            .log()          
		            .all()/*print all request + response logs in console dosen't matter error or validation its occur or not */
		            
		            .extract()
		            .response()
		            .asPrettyString();
			
		} 
}
