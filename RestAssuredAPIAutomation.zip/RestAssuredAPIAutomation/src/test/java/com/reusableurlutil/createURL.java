package com.reusableurlutil;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class createURL {
/* base uri is a fixed for that application
  changes in basepath, queryparam and path params only
 */
	/* so we can use public final static for baseuri increases the complete 
	reusalbility throught the project
	
	*/
	// return only baseuri
	public final static String baseURI = "https://reqres.in";
	                                                     	                                       
	public static String getBaseURI() {
		return baseURI;
	}	
	
	// returns baseuri+basepath both
	public static String getBasePath(String basePath) {
		
		return baseURI+basePath;
	}	
	
	
	//generate Stringpayload through json file
	public static String generateStringPayload(String fileName) throws IOException {
		   
        	String filePath = System.getProperty("user.dir")+"\\target\\JsonFilePayload"+fileName+".json";
			return new String(Files.readAllBytes(Paths.get(filePath)));
			
	}
	//read json file
	public static String readJSONFile(String fileName) {
		String filePath = System.getProperty("user.dir")+"\\target\\JsonFilePayload"+fileName+".json";
	    return filePath;
	}
	// read xml file
	public static String readXMLFile(String fileName) {
		String filePath = System.getProperty("user.dir")+"\\target\\xmlFilePayload"+fileName+".xml";
	    return filePath;
	}
}
