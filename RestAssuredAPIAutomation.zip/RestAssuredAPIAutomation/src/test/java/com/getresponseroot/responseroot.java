package com.getresponseroot;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.path.json.JsonPath;
import io.restassured.specification.RequestSpecification;


public class responseroot {
	
	@Test
	public void getReq_01() {
		
	 RequestSpecBuilder specBuilder = new RequestSpecBuilder();

	 /**
	  * 
	  * get response root
	  */
	
     specBuilder.setBaseUri("https://reqres.in/").setBasePath("api/users").addQueryParam("page", "2");
	  RequestSpecification reqBuild = specBuilder.build();
	   
 String response = RestAssured.
			             given()
			            .spec(reqBuild)
			            .when()
			            .get()	 
	                    .then()
			            .log()
			            .all()
			            .extract()
			            .response()
			            .asPrettyString();
	 
	 JsonPath jsonPath = new JsonPath(response);
	 
	 // 1st approch to get complete response body into varaibale
	 Object responseRoot1 = jsonPath.get("$");
	 System.out.println("responseRoot   :"+responseRoot1.toString());
	 
	 
	 // 2nd approch to get complete response body into varaibale
	 Object responseRoot2 = jsonPath.get("");
	 System.out.println("responseNAA    :"+responseRoot2.toString());
	 
	}
}
