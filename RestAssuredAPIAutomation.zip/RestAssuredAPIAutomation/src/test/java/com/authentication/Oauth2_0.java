package com.authentication;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Oauth2_0 {
	
	static String accesstoken;
	
	@Test(priority = 1)
	public void getAccessToken() {
		// generate access token
		//https://api-m.sandbox.paypal.com/v1/oauth2/token
	
    String clientID = "AajUIQvnhoK_gbWnInbVi02Gcwa962A8_ZyKeWa4-YYsI6iq";
    String  clientSecret = "EBsBf-D2N4CQiDtVFi6qQQpep3ryclEFFkosjv2LKfd_wkF7R";
		
	RequestSpecification requestSpec = RestAssured.given();
	requestSpec.baseUri("https://api-m.sandbox.paypal.com");
	requestSpec.basePath("/v1/oauth2/token");
	
	// basic auth
	Response response = requestSpec.auth().preemptive().basic(clientID,clientSecret ).param("grant_type", "client_credentials").post();
	
	String data = response.prettyPrint();
	String status = response.statusLine();
	System.out.println(status);
	
	JsonPath jsonpath = new JsonPath(data);
	
	accesstoken = jsonpath.get("access_token");
	
	System.out.println(accesstoken);
	
	}
	@Test(dependsOnMethods = "getAccessToken",priority = 2)
	public void getRequest() {
		
		Response res = RestAssured.given().auth().oauth2(accesstoken)
											 .queryParam("page","3")
											 .queryParam("page_size","4")
											 .queryParam("total_count_required",true )
											 .get("https://api-m.sandbox.paypal.com/v1/invoicing/invoices");
		
		res.prettyPrint();
	}	
}
