package com.pojo_jsoninclude_annotation;

public class Subjects {

	private String English;
	private String Hindi;
	public String getEnglish() {
		return English;
	}
	public void setEnglish(String english) {
		English = english;
	}
	public String getHindi() {
		return Hindi;
	}
	public void setHindi(String hindi) {
		Hindi = hindi;
	}
	
}
