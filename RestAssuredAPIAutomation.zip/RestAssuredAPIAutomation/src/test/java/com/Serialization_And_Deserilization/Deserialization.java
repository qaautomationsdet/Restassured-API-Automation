package com.Serialization_And_Deserilization;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.ObjectInputStream;

public class Deserialization {
public static void main(String[] args) {
	
	String str = "C:\\Users\\DELL\\eclipse-workspace-1\\RestAssuredAPIAutomation\\Src_dataFile.txt";
    
   try {
	FileInputStream fis = new FileInputStream(str);
	   
	   ObjectInputStream ois = new ObjectInputStream(fis);
	   
	    Student obj =(Student)ois.readObject();

	    System.out.println(obj.studentName);
	    System.out.println(obj.stuRollNO);
        System.out.println();
	    ois.close();
	    fis.close();
	    
	      
} catch (Exception e) {
	
	e.printStackTrace();
}
   }
}
