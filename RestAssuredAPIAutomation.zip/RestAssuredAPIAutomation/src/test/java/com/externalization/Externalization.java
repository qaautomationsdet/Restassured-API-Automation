package com.externalization;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

public class Externalization implements Externalizable{

	private static final long serelizableID = 1L;
	
	private int rollNo = 23;
	private String FName = "Prakash";
	private String LName = "Mali";
	public String getFName() {
		return FName;
	}
	public void setFName(String fName) {
		FName = fName;
	}
	public String getLName() {
		return LName;
	}
	public void setLName(String lName) {
		LName = lName;
	}

	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}

	public void writeExternal(ObjectOutput out) throws IOException {
		
		out.writeInt(rollNo);
	}
	public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
		
		rollNo = in.readInt();
	}
	
	
}
