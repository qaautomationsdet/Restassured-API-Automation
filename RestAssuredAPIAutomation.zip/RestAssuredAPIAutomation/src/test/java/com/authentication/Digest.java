package com.authentication;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Digest {
	
	@Test
		public void test01() {
			// Digest auth is more secured over the basic auth
			// digest auth for incoding and decoding uses Alogorithm 
			
			RequestSpecification  requestSpec = RestAssured.given();
			
			//https://postman-echo.com/basic-auth
			requestSpec.baseUri("http://httpbin.org");
			requestSpec.basePath("/digest-auth/undefined/auth/auth");
			
			Response response = requestSpec.auth()
					                       .digest("auth","auth")
					                       .get();
			
			System.out.println("Response status :" + response.statusLine());
			System.out.println(response.asPrettyString());	
		
	}
}
