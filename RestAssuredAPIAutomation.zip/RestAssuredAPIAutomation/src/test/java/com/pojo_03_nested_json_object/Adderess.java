package com.pojo_03_nested_json_object;

public class Adderess {

	
	private int house;
	private String country;
	
	
	public int getHouse() {
		return house;
	}
	public void setHouse(int house) {
		this.house = house;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
}
