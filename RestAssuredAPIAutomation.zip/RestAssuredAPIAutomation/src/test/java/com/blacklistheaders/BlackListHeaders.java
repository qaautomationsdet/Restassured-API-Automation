package com.blacklistheaders;
import java.util.ArrayList;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.LogConfig;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;
public final class BlackListHeaders {

	/* purpose of blacklisting headers : is to prevent sensitive information into the log
	   we can hide multiple headers - requestheaders and responseheaders.
	   must be need to write blacklisting headers code before the .log method
	
	 .config(RestAssured.config.logConfig(LogConfig.logConfig().blacklistHeader("headerkey","headerkey,....,.....,.....,...)))
	
	  only value blacklisted key is visible
	  
	  // in console you will see 
	   
	   	  ContentType - [BLACKLISTED]
	   
	   */

	@Test
	public void getReq_01() {
		
	 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		 
	 specBuilder.setBaseUri("https://reqres.in")
	            .setBasePath("/api/users")
	            .addQueryParam("page", "2");
             
	  RequestSpecification reqBuild = specBuilder.build();
	   
				 Response response = RestAssured.
									             given()								          
									            .spec(reqBuild)    
									                             // we have hide request header                     | use header key| 
									            .config(RestAssured.config.logConfig(LogConfig.logConfig().blacklistHeader("Accept")))
									            .log()								                                       //request header 
									            .all()
									            .when()
									            .get();
ValidatableResponse validatbleRes = response .then();
							            			
                                              // we dont need to write seperately for response headers like this
	           String extarctRes = validatbleRes.//.config(RestAssured.config.logConfig(LogConfig.logConfig().blacklistHeader("headerkey")))
	        		                             log()
		                                        .all()
									            .extract()
									            .response()
									            .asPrettyString();
					     
	                              // validate the response
	                              validatbleRes.assertThat()
	                                            .statusCode(200)
	                                            .statusLine("HTTP/1.1 200 OK");
	                                                                                                  
	}	
	@Test
	public void getReq_02() {
		
	 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		 
	 specBuilder.setBaseUri("https://reqres.in")
	            .setBasePath("/api/users")
	            .addQueryParam("page", "2");

	  RequestSpecification reqBuild = specBuilder.build();
	   
				 Response response = RestAssured.
									             given()								          
									            .spec(reqBuild)
									             // we have hide request and response headers mutiples also     | use header key|
									            .config(RestAssured.config.logConfig(LogConfig.logConfig().blacklistHeader("Accept","Transfer-Encoding")))
									            .log()								                                     //request hea       response hea
									            .all()
									            .when()
									            .get();
ValidatableResponse validatbleRes = response .then();
							            								            		 
	           String extarctRes = validatbleRes
	        		                            .log()
		                                        .all()
									            .extract()
									            .response()
									            .asPrettyString();
					     
	                              // validate the response
	                              validatbleRes.assertThat()
	                                            .statusCode(200)
	                                            .statusLine("HTTP/1.1 200 OK");
	                                                                                                  
	}	
	
	// way 2nd blacklist headers
	@Test
	public void getReq_03() {
		
	 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		 
	 specBuilder.setBaseUri("https://reqres.in")
	            .setBasePath("/api/users")
	            .addQueryParam("page", "2");
             
	  RequestSpecification reqBuild = specBuilder.build();
	   
	  // using collection -  arraylist [first we will add the headers key in arraylist] the use the variable
	  ArrayList blackListHeaders = new ArrayList();
	  blackListHeaders.add("Accept");
	  blackListHeaders.add("Transfer-Encoding");
	  
				 Response response = RestAssured.
									             given()								          
									            .spec(reqBuild)    
									                                                         
									            .config(RestAssured.config.logConfig(LogConfig.logConfig().blacklistHeaders(blackListHeaders)))
									            .log()								                                       
									            .all()
									            .when()
									            .get();
ValidatableResponse validatbleRes = response .then();
							            			
                                              
	           String extarctRes = validatbleRes.
	        		                             log()
		                                        .all()
									            .extract()
									            .response()
									            .asPrettyString();
					     
	                              // validate the response
	                              validatbleRes.assertThat()
	                                            .statusCode(200)
	                                            .statusLine("HTTP/1.1 200 OK");
                                                                                               
	}	
	
		@Test
		public void Req_04() {
			
		 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
			 
		 specBuilder.setBaseUri("https://reqres.in")
		            .setBasePath("/api/users")
		            .addQueryParam("page", "2")
		            .setConfig(RestAssured.config.logConfig(LogConfig.logConfig().blacklistHeader("Accept")));
		            
	             
		  RequestSpecification reqBuild = specBuilder.build();
		   
					 Response response = RestAssured.
										             given()								          
										            .spec(reqBuild) 
										            .log()								                                       
										            .all()
										            .when()
										            .get();
	ValidatableResponse validatbleRes = response .then();
								            			           
		           String extarctRes = validatbleRes.
		        		                             log()
			                                        .all()
										            .extract()
										            .response()
										            .asPrettyString();
						     
		                              // validate the response
		                              validatbleRes.assertThat()
		                                            .statusCode(200)
		                                            .statusLine("HTTP/1.1 200 OK");
	                                                                                               
		
		                            /* "HTTP/1.1 200 OK" 
		                             
		                               protocol      : HTTP 
		                               version       : 1.1
		                               status text   : OK
		                               ststus code   : 200 */
		}	
}
