package com.proxyserver;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.specification.RequestSpecification;

public class Request {
/*	A proxy server acts as an intermediary between a client (such as a web browser) and another server. 
	When a client makes a request for a resource, instead of directly contacting the server that hosts the resource, 
	the request is first sent to the proxy server. 
	The proxy server then forwards the request to the appropriate server, retrieves the response, and sends it back to the client.

                             client      <-->      proxyserver   <-->    main server
                             
   A proxy server can mask the client's IP address,
   This can help protect the client's identity and location.                          
*/
	
	 RestAssuredConfig config = RestAssured.config()
             .sslConfig(new SSLConfig().allowAllHostnames().relaxedHTTPSValidation());
		
	@Test
	public void getReq_01() {

	 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		 
     specBuilder.
     
      setBaseUri("https://reqres.in").
      setBasePath("/api/users")
     .addQueryParam("page", "2");
	  RequestSpecification reqBuild = specBuilder.build();
	   
	 RestAssured.
	             given()
	            .proxy("localhost",12234)
	            .config(config)
	            .spec(reqBuild)
	            .when()
	            .get()
	            .then()
	            .log()
	            .all()
	            .extract()
	            .response()
	            .asPrettyString();
		
	}
 }
