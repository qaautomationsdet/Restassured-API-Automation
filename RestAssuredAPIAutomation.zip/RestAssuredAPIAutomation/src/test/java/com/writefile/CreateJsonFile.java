package com.writefile;
import java.io.FileWriter;
import java.io.IOException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.specification.RequestSpecification;

public class CreateJsonFile {
	 RestAssuredConfig config = RestAssured.config()
             .sslConfig(new SSLConfig().allowAllHostnames().relaxedHTTPSValidation());
		SimpleDateFormat sdf = new SimpleDateFormat("dd-mm-YYYY hh-mm-ssss-aa");
		Date  d = new Date();
		
		String currentDate;
		
//	@Test
	public void getReq_01() {	
		JSONObject j = new JSONObject();
		j.put("name","abc");
		j.put("job","testing");	
	
		
     	System.out.println();

		try {
			FileWriter file = new FileWriter(".\\src\\test\\resources\\WritedFile\\"+currentDate+" JSONOutput.json");
			file.write(j.toJSONString());
			file.close();
			System.out.println("Json file Created Sucessfully file name is....."+currentDate+" JSONOutput.json");
		} catch (IOException e) {
		
			e.printStackTrace();
		}
	}
	@Test
	public void getReq_02() {

	 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		 
     specBuilder.setBaseUri("https://reqres.in").setBasePath("/api/users").addQueryParam("page", "2");
	  RequestSpecification reqBuild = specBuilder.build();
	   
	String response = RestAssured.
	             given()
	             .config(config)
	            .spec(reqBuild)
	            .when()
	            .get()
	            .then()
	            .log()
	            .all()
	            .extract()
	            .response()
	            .asPrettyString();

	 try {
			  currentDate = sdf.format(d);
		
			FileWriter file = new FileWriter(".\\src\\test\\resources\\WritedFile\\"+currentDate+" JSONOutput.json");
			file.write(response);
			file.close();
			System.out.println("Json file Created Sucessfully file name is.....  "+currentDate+" JSONOutput.json");
		} catch (IOException e) {
		
			e.printStackTrace();
		}
	}
	
}
