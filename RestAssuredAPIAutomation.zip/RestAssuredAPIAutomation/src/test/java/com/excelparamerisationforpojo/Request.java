package com.excelparamerisationforpojo;

import java.io.IOException;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class Request {
	RestAssuredConfig config = RestAssured.config()
			.sslConfig(new SSLConfig().allowAllHostnames().relaxedHTTPSValidation());

	@Test
	public void postRequest() throws IOException {

		Pojo p = new Pojo();
		p.setName(ReadExcel.readExcelData(2, 2));
		p.setJob(ReadExcel.readExcelData(4, 2));

		RequestSpecBuilder specBuilder = new RequestSpecBuilder();

		specBuilder
		.setBaseUri("https://reqres.in")
		.setBasePath("/api/users")
		.setBody(p)
		.setContentType(ContentType.JSON)
		.setConfig(config);

		RequestSpecification reqSecification = specBuilder.build();

		Response response = RestAssured
				.given()
				.spec(reqSecification)
				.log()
				.all()
				.when()
				.post();

		ValidatableResponse validatableRes = response.then();

		String extractRes = validatableRes
				.log()
				.all()
				.extract()
				.response()
				.asString();

	}
}
