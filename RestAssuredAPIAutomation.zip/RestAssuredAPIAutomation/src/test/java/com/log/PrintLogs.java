package com.log;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.specification.RequestSpecification;

public class PrintLogs {
	 RestAssuredConfig config = RestAssured.config()
             .sslConfig(new SSLConfig().allowAllHostnames().relaxedHTTPSValidation());
		
	 @Test
	 public void getReq_0() {

	 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		 
     specBuilder.setBaseUri("https://reqres.in").setBasePath("/api/users").addQueryParam("page", "2");
	 RequestSpecification reqBuild = specBuilder.build();
	   
	 RestAssured.
	             given()
	             .config(config)
	            .spec(reqBuild)
	            
	            .log()
	            
	            .all() /*prints  only all request logs into console*/
	            
	            .when()
	            .get()
	            .then()
	            .extract()
	            .response()
	            .asPrettyString();
		
	}
	@Test
	public void getReq_01() {

	 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		 
     specBuilder.setBaseUri("https://reqres.in").setBasePath("/api/users").addQueryParam("page", "2");
	 RequestSpecification reqBuild = specBuilder.build();
	   
	 RestAssured.
	             given()
	             .config(config)
	            .spec(reqBuild)
	            .when()
	            .get()
	            .then()
	                     // method use after .then
	            .log()          
	            .all()/*print all request + response logs in console....Everything*/
	            
	            .extract()
	            .response()
	            .asPrettyString();
		
	}
	//@Test
	public void getReq_02() {

	 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		 
     specBuilder.setBaseUri("https://reqres.in").setBasePath("/api/users").addQueryParam("page", "2");
	  RequestSpecification reqBuild = specBuilder.build();
	   
	 RestAssured.
	             given()
	             .config(config)
	            .spec(reqBuild)            
	            .when()
	            .get()
	            .then()
	            
	            .log()
	            .body()/*print only body in console*/
	       
	            
	            .extract()
	            .response()
	            .asPrettyString();
		
	}
  @Test
	public void getReq_03() {

	 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		 
     specBuilder.setBaseUri("https://reqres.in").setBasePath("/api/users").addQueryParam("page", "2");
	  RequestSpecification reqBuild = specBuilder.build();
	   
	 RestAssured.
	             given()
	             .config(config)
	            .spec(reqBuild)            
	            .when()
	            .get()
	            .then()
	            
	            .log() 
	            .headers()/*print only headers in console*/
	                  
	            .extract()
	            .response()
	            .asPrettyString();
		
	}
	@Test
		public void getReq_04() {

		 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
			 
	     specBuilder.setBaseUri("https://reqres.in").setBasePath("/api/users").addQueryParam("page", "2");
		  RequestSpecification reqBuild = specBuilder.build();
		   
		 RestAssured.
		             given()
		             .config(config)
		            .spec(reqBuild)            
		            .when()
		            .get()
		            .then()
		            
		            .log() 
		            .headers()/*print only headers in console*/
		                  
		            .extract()
		            .response()
		            .asPrettyString();
			
		}
	 @Test
		public void getReq_05() {

		 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
			 
	     specBuilder.setBaseUri("https://reqres.in").setBasePath("/api/users").addQueryParam("page", "2");
		  RequestSpecification reqBuild = specBuilder.build();
		   
		 RestAssured.
		             given()
		            .config(config)
		            .spec(reqBuild)         
		            .when()
		            .get()
		            .then()
		            .log().status()  /* Here print only status log*/ 
		            .extract()
		            .response()
		            .asPrettyString();
		}
	 
    @Test
	public void getReq_06() {

	 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		 
     specBuilder.setBaseUri("https://reqres.in").setBasePath("/api/users").addQueryParam("page", "2");
	  RequestSpecification reqBuild = specBuilder.build();
	   
	 RestAssured.
	             given()
	            .config(config)
	            .spec(reqBuild)       /* Here not .log() method it means in console dosen't print anything*/     
	            .when()
	            .get()
	            .then()
	            .extract()
	            .response()
	            .asPrettyString();
		
	}
}
