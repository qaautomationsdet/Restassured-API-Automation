package com.fakerclass;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;
import com.github.javafaker.Faker;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class CreatePayloadUsingFakerClass {

	@Test
	public void PostRequest() {

	    // Faker
		
		/*Faker Provides utility methods for generating fake strings, such as names, phone numbers, addresses.
		generate random strings with given patterns*/
			
		// Faker is depedency required in POM.xml we can gerenate automatic data using diff methods
		Faker faker = new Faker();	
			
		// for this JSONObject class required // json-simple // dependency in POM.xml
		JSONObject payload = new JSONObject();
		
		payload.put("name",faker.name().fullName());
		payload.put("gender","male");
		payload.put("email",faker.internet().emailAddress());
		payload.put("status","active");
		
		String bearerToken = "Bearer "+"4488a6386727c443b96ef8c05aa44c1049589de7de1e71f2a3787544696d1bb7";
		
		RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		
		specBuilder.setBaseUri("https://gorest.co.in")
		           .setBasePath("/public/v2/users")
		           .addHeader("Authorization",bearerToken)
		           .setContentType(ContentType.JSON)
		           .setBody(payload.toJSONString());
				
		RequestSpecification requestBuild = specBuilder.build();
		
									     Response reponse = RestAssured.given()
												           .spec(requestBuild)
												           .log()
												           .all()
												           .when()
												           .post();
									                        
          ValidatableResponse validatableResponse = reponse.then();
                 
                  String responseBody = validatableResponse.log()
												           .all()
												           .extract()
												           .response()
												           .asPrettyString();
												
                                        // validation expeceted status code
                                        validatableResponse.statusCode(201);
                                               
	}
}
