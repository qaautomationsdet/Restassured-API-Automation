package com.exceptions;
public class classcastException {

	public static void main(String[] args) {
		
		Integer a = 10;
		
		Object o=a;
		
		String b =(String)o;
		
		System.out.println(b);
		
		//---------------------------------------------
		
		Double d = 20.2;
		
	    Object x=d;
	    
	    String y = x.toString();
		System.out.println(y);
		
		
	}
}
