package com.cache;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Request1 {
	
	 RestAssuredConfig config = RestAssured.config()
				.sslConfig(new SSLConfig().allowAllHostnames().relaxedHTTPSValidation());

	@Test
	public void getReq_01() {
		
		/*
		 'Cache-Control' headers help you define the caching policies such as max-age, no-cache, no-store, etc.
		 */
		
	 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		 
     specBuilder.setBaseUri("https://reqres.in")
                .setBasePath("/api/users")
                .addQueryParam("page", "2")
                .addHeader("Cache-Control", "no-cache");
     
	  RequestSpecification reqBuild = specBuilder.build();
	   
	 RestAssured.
	             given()
	             .config(config)
	            .spec(reqBuild)
	            .when()
	            .get()
	            .then()
	            .log()
	            .all()
	            .extract()
	            .response()
	            .asPrettyString();
		
	}
	
	@Test
	public void getReq_02() {
		
		/*
		 Validate Cache Headers in Responses: Ensure that your API responses include the appropriate cache headers.
		 */
		
	 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		 
     specBuilder.setBaseUri("https://reqres.in")
                .setBasePath("/api/users")
                .addQueryParam("page", "2")
                .addHeader("Cache-Control", "no-cache");
     
	  RequestSpecification reqBuild = specBuilder.build();
	   
	 RestAssured.
	             given()
	             .config(config)
	            .spec(reqBuild)
	            .when()
	            .get()
	            .then()
	            .header("Cache-Control", "max-age=3600")
	            .log()
	            .all()
	            .extract()
	            .response()
	            .asPrettyString();
		
	}
	
	@Test
	public void getReq_03() {
		
		/*
		 ETags help in validating cache and make conditional requests to save bandwidth and improve performance.
		 */
		
		Response response = RestAssured.given()
			    .when()
			    .get("/your-endpoint");

			String eTag = response.header("ETag");

			// Use the ETag in the If-None-Match header for subsequent requests
			     RestAssured.given()
			    .header("If-None-Match", eTag)
			    .when()
			    .get("/your-endpoint")
			    .then()
			    .statusCode(304); // 304 Not Modified
	}
	
	@Test
	public void getReq_04() {
		
		/*
	        You can disable caching by setting appropriate headers.
		 */
		
	RestAssured.given()
	    .header("Cache-Control", "no-store")
	    .when()
	    .get("/your-endpoint")
	    .then()
	    .statusCode(200);
	}
	
	@Test
	public void getReq_05() {
		 // Set base URI
        RestAssured.baseURI = "https://api.example.com";

        // Make a request with Cache-Control headers
        Response response = RestAssured.given()
            .header("Cache-Control", "no-cache")
            .when()
            .get("/your-endpoint");

        // Validate the response status code and headers
        response.then()
            .statusCode(200)
            .header("Cache-Control", "no-store");

        // Extract ETag from the response
        String eTag = response.header("ETag");

        // Make a conditional request using ETag
        RestAssured.given()
            .header("If-None-Match", eTag)
            .when()
            .get("/your-endpoint")
            .then()
            .statusCode(304); // 304 Not Modified
	}
}
