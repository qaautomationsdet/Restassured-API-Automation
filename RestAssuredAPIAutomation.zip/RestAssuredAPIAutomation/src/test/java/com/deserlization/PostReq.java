package com.deserlization;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.junit.Assert;
import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class PostReq {
	                      //convert json response to java object it is also known as deserialization      
	
	 RestAssuredConfig config = RestAssured.config()
             .sslConfig(new SSLConfig().allowAllHostnames().relaxedHTTPSValidation());
	@Test
	public void postReq_03() throws IOException {		
		// java map
		
		Map map = new LinkedHashMap();
		map.put("name", "jhon");
		map.put("job", "QA");
	
		System.out.println(map);
		
	RequestSpecBuilder specBuilder = new RequestSpecBuilder();
	
	specBuilder.setBaseUri("https://reqres.in");
	specBuilder.setBasePath("/api/users");
	specBuilder.setBody(map);
	specBuilder.setContentType(ContentType.JSON);	
	
	RequestSpecification reqSecification = specBuilder.build();
	
				Response response = RestAssured.given()
											           .spec(reqSecification)
											           .config(config)
											           .log()
											           .all()
											           .when()
											           .post();
	
	 ValidatableResponse validatableRes = response.then();
	       
	            String extractRes = validatableRes.log()
	                                              .all()
	                                              .extract()
	                                              .response()
	                                              .asString();

	  
	      
	      ObjectMapper objMapper = new ObjectMapper();
	     Deseralize dclass = objMapper.readValue(extractRes,Deseralize.class);
	    
	      System.out.println("-------------------------------------------------------------------------------------------");
	      
	      System.out.println("student id " + dclass.getId());
	      System.out.println("student name "+ dclass.getName());
	      System.out.println("job  "+ dclass.getJob());
          System.out.println("createdAt " + dclass.createdAt);
          
          
	}
}
