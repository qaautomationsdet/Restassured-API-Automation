package com.pojo_jsonignoreproperties_annotation_ignore_knownfields_from_seri_and_dese_n;

import com.fasterxml.jackson.annotation.JsonIgnore;

// we have ignored this field from serialization and deserialization at field level

public class MyPojo {

	private String firstName;
	
	
	private String lastName;
	
	@JsonIgnore  // i have ignored this field for serialization and deserialization 
	private String address;
	

	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
}
