package com.pojo_03_nested_json_object;

public class Employee {

	
	private int id;
	private String firstname;
	private Adderess address;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public Adderess getAddress() {
		return address;
	}
	public void setAddress(Adderess address) {
		this.address = address;
	}
	
	
}
