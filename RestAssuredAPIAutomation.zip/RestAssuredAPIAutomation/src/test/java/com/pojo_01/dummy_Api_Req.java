package com.pojo_01;
import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class dummy_Api_Req {
	
	@Test
	public void req() {
		
		 /* {
		  "id":1;
		  "firstname": "Jim",
		  "lastname": "Brown",
		  "gender":"male",
		  "address":"india"
		} */
		student std = new student();
		std.setId(1);
		std.setFirstname("jim");
		std.setLastname("Brown");
		std.setGender("male");
		std.setAddress("india");
		
		String response = RestAssured
		          .given()
		          .log()
		          .all()
		          .body(std)
		          .when()
		          .get()
		          .then()
		          .log()
		          .all()
		          .extract()
		          .response()
		          .asString();
		       		
	}
}
