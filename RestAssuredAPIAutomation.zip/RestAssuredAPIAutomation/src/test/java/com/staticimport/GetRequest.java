package com.staticimport;
import java.util.Map;

// regular imports
import org.hamcrest.Matchers;
import io.restassured.RestAssured;


// static imports
import static org.hamcrest.Matchers.*;
import static io.restassured.RestAssured.*;

import org.testng.annotations.Test;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.specification.RequestSpecification;

public class GetRequest {
	
	/**
	 java static import feature allows to access the 
	 static members of a class without the class name 
	 **/
	
	@Test
	// using static import
			public void getReq_01() {
				
			 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
				 
			 specBuilder.setBaseUri("https://reqres.in").setBasePath("/api/users").addQueryParam("page", "2");

			  RequestSpecification reqBuild = specBuilder.build();
			  
			 // using static import 
			             given()
			            .spec(reqBuild)
			            .when()
			            .get()
			            .then() // "" and $  => specified hole reponse type
			            .body("",instanceOf(Map.class)) // using static in Matchers class
			            .log() 
			            .all()
			            .extract()
			            .response()
			            .toString();
			 
	}	
	@Test
	// Without using static import
			public void getReq_02() {
				
			 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
				 
			 specBuilder.setBaseUri("https://reqres.in").setBasePath("/api/users").addQueryParam("page", "2");

			 RequestSpecification reqBuild = specBuilder.build();
			  
			 // Without using static import
			 RestAssured.given()
			            .spec(reqBuild)
			            .when()
			            .get()
			            .then() //   "" OR $  => specifies hole reponse 
			            .body("",Matchers.instanceOf(Map.class)) //Without using static import in Matchers class
			            .log() 
			            .all()
			            .extract()
			            .response()
			            .toString();
			 
	}	
}
