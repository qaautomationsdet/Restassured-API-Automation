package com.xmlpayload;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class XmlPayload {
	
	RestAssuredConfig config = RestAssured.config()
            .sslConfig(new SSLConfig().allowAllHostnames().relaxedHTTPSValidation());
	
	//@Test
	public void xmlpayloadrequest() throws IOException {
			
	String payload = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\r\n"
			+ "<root>\r\n"
			+ "  <name>morpheus</name>\r\n"
			+ "  <job>leader</job>\r\n"
			+ "</root>";
	
RequestSpecBuilder specBuilder = new RequestSpecBuilder();

specBuilder.setBaseUri("https://reqres.in").setBasePath("/api/users")
.addHeader("accept","application/xml")
.addHeader("Content-Type","application/xml")
.setBody(payload)
.setConfig(config);

RequestSpecification reqSecification = specBuilder.build();

Response response = RestAssured.given()
							           .spec(reqSecification)
							           .log()
							           .all()
							           .when()
							           .post();

ValidatableResponse validatableRes = response.then();
       
            String extractRes = validatableRes.log()
                                              .all()
                                              .extract()
                                              .response()
                                              .asPrettyString();

	}    
	
	@Test
	public void xmlPostReq() {

		String xmlpayload = "<Pet>\r\n"
				+ "	<id>0</id>\r\n"
				+ "	<Category>\r\n"
				+ "		<id>0</id>\r\n"
				+ "		<name>string</name>\r\n"
				+ "	</Category>\r\n"
				+ "	<name>doggie</name>\r\n"
				+ "	<photoUrls>\r\n"
				+ "		<photoUrl>string</photoUrl>\r\n"
				+ "	</photoUrls>\r\n"
				+ "	<tags>\r\n"
				+ "		<Tag>\r\n"
				+ "			<id>0</id>\r\n"
				+ "			<name>string</name>\r\n"
				+ "		</Tag>\r\n"
				+ "	</tags>\r\n"
				+ "	<status>available</status>\r\n"
				+ "</Pet>";

		      String response = RestAssured.given()
		                         .baseUri("https://petstore.swagger.io/v2/pet")
				                 .header("accept","application/xml")
				                 .header("Content-Type","application/xml")
		                         .body(xmlpayload)	
		                         .config(config)
				                 .when()
				                 .post()
				                 .then()
				                 .log()
				                 .all()
				                 .extract()
				                 .response()
				                 .asPrettyString();
		
		
		System.out.println("reponseBody :"+response);

	}
}
