package com.externalization;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.Serialization_And_Deserilization.Student;

public class Operation {

	public static void main(String[] args) {
		
		Externalization ext = new Externalization();
		ext.setRollNo(1);
		ext.setFName("Prakash");
		ext.setLName("Mali");

		
		String str = "C:\\Users\\DELL\\eclipse-workspace-1\\RestAssuredAPIAutomation\\Src_dataFile_1.txt";
		
		try {
			
			FileOutputStream fos = new FileOutputStream(str);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(ext);
			oos.close();
			fos.close();
			
			System.out.println("Object svaed in the file");
			
			FileInputStream fis = new FileInputStream(str); 
			ObjectInputStream ois = new ObjectInputStream(fis);
			   
			Externalization   obj =(Externalization)ois.readObject();

			    System.out.println(obj.getRollNo());
			    System.out.println(obj.getFName());
			    System.out.println(obj.getLName());

			    ois.close();
			    fis.close();
			    
			System.out.println("Object readed sucessfully");    
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
