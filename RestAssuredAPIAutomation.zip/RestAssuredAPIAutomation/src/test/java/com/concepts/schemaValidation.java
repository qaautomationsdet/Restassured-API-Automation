package com.concepts;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.hamcrest.MatcherAssert;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class schemaValidation {
	
	  String projectPath = System.getProperty("user.dir");
	
	 RestAssuredConfig config = RestAssured.config()
             .sslConfig(new SSLConfig().allowAllHostnames().relaxedHTTPSValidation());
	 //   @Test
		public void postReq_05() throws IOException {		
			// java Collection - list
					
		String payload = "{\r\n"
				+ "    \"firstname\" : \"Jim\",\r\n"
				+ "    \"lastname\" : \"Brown\",\r\n"
				+ "    \"totalprice\" : 111,\r\n"
				+ "    \"depositpaid\" : true,\r\n"
				+ "    \"bookingdates\" : {\r\n"
				+ "        \"checkin\" : \"2018-01-01\",\r\n"
				+ "        \"checkout\" : \"2019-01-01\"\r\n"
				+ "    },\r\n"
				+ "    \"additionalneeds\" : \"Breakfast\"\r\n"
				+ "}";
			
		RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		
		specBuilder.setBaseUri("https://restful-booker.herokuapp.com").setBasePath("/booking")
		.setBody(payload)
		.setContentType(ContentType.JSON);	
		RequestSpecification reqSecification = specBuilder.build();
		
		Response response = RestAssured.given()
									           .spec(reqSecification)
									           .config(config)
									           .log()
									           .all()
									           .when()
									           .post();
		
		ValidatableResponse validatableRes = response.then();
		       
		            String extractRes = validatableRes.log()
		                                              .all()
		                                              .extract()
		                                              .response()
		                                              .asString();
     // .json file in resource folder then use its not mandate=  JsonSchemaValidator.matchesJsonSchemaInClasspath         
    // validatableRes.body(JsonSchemaValidator.matchesJsonSchemaInClasspath("createBokkingJsonSchema.json"));
     
     // .json file not in resource folder then use its not mandate = JsonSchemaValidator.matchesJsonSchema
    String projectPath = System.getProperty("user.dir");
	validatableRes.body(JsonSchemaValidator.matchesJsonSchema(projectPath+"\\createBokkingJsonSchema_1.json"));	            
		            
  }	
	// @Test
	 public void jsonSchema() {
		 
		 String payload = "{\r\n"
					+ "    \"firstname\" : \"Jim\",\r\n"
					+ "    \"lastname\" : \"Brown\",\r\n"
					+ "    \"totalprice\" : 111,\r\n"
					+ "    \"depositpaid\" : true,\r\n"
					+ "    \"bookingdates\" : {\r\n"
					+ "        \"checkin\" : \"2018-01-01\",\r\n"
					+ "        \"checkout\" : \"2019-01-01\"\r\n"
					+ "    },\r\n"
					+ "    \"additionalneeds\" : \"Breakfast\"\r\n"
					+ "}";
		 
	//	 MatcherAssert.assertThat(payload,JsonSchemaValidator.matchesJsonSchemaInClasspath("createBokkingJsonSchema.json"));
	 }	
	 
		@Test
		public void postReq_01() {
			// payload as string
			
			String reqPaylod = "{\r\n"
					+ "    \"name\": \"morpheus\",\r\n"
					+ "    \"job\": \"leader\"\r\n"
					+ "}";
			
		RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		
		specBuilder.setBaseUri("https://reqres.in").setBasePath("/api/users")
		.setBody(reqPaylod)
	    .setContentType(ContentType.JSON)
	    .setConfig(config);
		
		RequestSpecification reqSecification = specBuilder.build();
		
		Response response = RestAssured.given()
									           .spec(reqSecification)
									           .log()
									           .all()
									           .when()
									           .post();
		
		ValidatableResponse validatableRes = response.then();
		       
		            String extractRes = validatableRes.log()
		                                              .all()
		                                              .extract()
		                                              .response()
		                                              .asString();
		            validatableRes.assertThat().body(JsonSchemaValidator.matchesJsonSchema(projectPath+"\\requresJSONSchema.json"));   
		       response    =   validatableRes.extract().response();
		       System.out.println("response "+response);
		}
}
