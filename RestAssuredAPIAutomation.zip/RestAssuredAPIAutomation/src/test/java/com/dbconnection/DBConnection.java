package com.dbconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.testng.annotations.Test;

public class DBConnection {
	
	@Test
	public void mySQLConnection() {
		
		try {
			
			String mySQLUrl = "jdbc:mysql://localhost/sample_databse";
			Connection connect = DriverManager.getConnection(mySQLUrl,"username","password");
					
			Statement statement = connect.createStatement();
			
			String query = "SELECT * FROM TABLENAME";
			
			ResultSet data = statement.executeQuery(query);
			
			connect.close();
			
		} catch (SQLException e) {
			
		}
		
	}
	
}
