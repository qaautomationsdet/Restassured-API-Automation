package com.pojo_jsoninclude_annotation;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.pojo_jsonpropertyorder_annotation.Address;

/*at the time of operation they only includes Nonnull fields
and this condition is applicable for root + all nested classes 
*/
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Employee {
	
	private String lName;
	private String fName;
	private Address address;
	
	
	
	
	
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	
}
