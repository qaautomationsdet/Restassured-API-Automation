package com.apichainingin_diffclasess;

import org.testng.ITestContext;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class Tc_04_DeleteUser {
	
	 RestAssuredConfig config = RestAssured.config()
             .sslConfig(new SSLConfig().allowAllHostnames().relaxedHTTPSValidation());
	
	@Test 
	public void DeleteUser(ITestContext context) {
		
		System.out.println("*****************  DELETE REQUEST ******************");
		
		
		int id = (Integer) context.getAttribute("user_id") ;
		
		RequestSpecBuilder specBuilder = new RequestSpecBuilder();

		String bearerToken = "Bearer "+"4488a6386727c443b96ef8c05aa44c1049589de7de1e71f2a3787544696d1bb7";

				specBuilder.setBaseUri("https://gorest.co.in")
			               .setBasePath("/public/v2/users/"+id)
				           .addHeader("Authorization",bearerToken)
				           .setContentType(ContentType.JSON)
				           .setConfig(config);
				         
						
				RequestSpecification requestBuild = specBuilder.build();
				
											     Response reponse = RestAssured.given()
														           .spec(requestBuild)
														           .log()
														           .all()
														           .when()
														           .delete();
											                        
		          ValidatableResponse validatableResponse = reponse.then();
		                 
		                  String responseBody = validatableResponse.log()
														           .all()
														           .extract()
														           .response()
														           .asPrettyString();
														
		                                        // validations
		                                        // expected status code
		                                        validatableResponse.statusCode(204);
		                                                       
		                  JsonPath jsonPath = new JsonPath(responseBody);    
		                  
	}
}
