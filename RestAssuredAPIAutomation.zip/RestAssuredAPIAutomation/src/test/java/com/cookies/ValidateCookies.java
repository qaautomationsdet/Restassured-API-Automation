package com.cookies;

import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class ValidateCookies {
	@Test
	public void cookies() {
		
		 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		 
		 specBuilder.setBaseUri("http://httpbin.org/get");
	//	 specBuilder.setBasePath("http://httpbin.org/get");
		  RequestSpecification reqBuild = specBuilder.build();
		   
					 Response response = RestAssured.
										             given()
										            .spec(reqBuild)
										            .log()
										            .all()
										            .when()
										            .get();
	   ValidatableResponse validatbleRes = response .then();
								            								            		 
		         String ResponseBody = validatbleRes.log()
										            .all()
										            .extract()
										            .response()
										            .asPrettyString();
						            
		                              validatbleRes.assertThat()
		                                            .statusCode(200)
		                                            .statusLine("HTTP/1.1 200 OK");
		                                                                                     
		          JsonPath jsonPath = new JsonPath(ResponseBody);  
		              
		          // get all the cokkies
		          Map<String, String> cookies = response.getCookies();     		               
		          System.out.println("cookies  : "+cookies);
		          // cokkies are not present
		               
		          // get specific cookies
		          String getSpecificCookie = response.getCookie(/*cookiename*/"cookieName");
		          System.out.println(getSpecificCookie);
	
	  }	
}
