package com.excelparamerisationforpojo;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ReadExcel {

	public static String readExcelData(int row , int col) throws IOException {
		String filePath = System.getProperty("user.dir")+"\\src\\test\\resources\\ExcelData\\RestassuredTestData.xlsx";
		FileInputStream file = new FileInputStream(filePath);
		String data = WorkbookFactory.create(file).getSheet("Sheet1").getRow(row).getCell(col).getStringCellValue();
		
		return data;
	}
}
