package com.pojo_jsoninclude_annotation;

import com.fasterxml.jackson.annotation.JsonInclude;

/*at the time of operation only includes nonnull and nonempty  fields
   but nonempty behavior is applied for Address class 
   
   Note : NonNull condition applied for both or all clasess
          NonEmpty condition specific to the  Address class only 
   
 */
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class Address {
	
	private String city;
	private String zipCode;
	private String state;
	

	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}

}
