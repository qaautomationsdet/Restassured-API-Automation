package com.pojo_jsonignoreproperties_annotation_ignore_unknownfields_from_ser_and_deseri_n;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/*for ignoring unknown fields at the time of deserialization 
 use can use @JsonIgnoreProperties(ignoreUnkown =true) for your
 root class of the pojo
 
 Note : in some cases nested pojo tree you can add only 
 the root class of the pojo, no need to add for every nested 
 pojo classes.
 
 its ignores the unknown fields and deserialize the only known fields 
*/
@JsonIgnoreProperties(ignoreUnknown = true)
public class MyPojo {

	private String fName;
	private String lName;
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	
}
