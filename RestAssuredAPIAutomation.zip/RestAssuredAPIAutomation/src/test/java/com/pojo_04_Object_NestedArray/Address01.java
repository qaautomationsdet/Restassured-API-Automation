package com.pojo_04_Object_NestedArray;

public class Address01 {

	private int house;
	private String country;
	
	
	public int getHouse() {
		return house;
	}
	public void setHouse(int house) {
		this.house = house;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
}
