package com.pojo_jsoninclude_annotation;

import com.fasterxml.jackson.annotation.JsonInclude;

// same time multiple include conditions
//@JsonInclude(value = {JsonInclude.Include.NON_NULL,JsonInclude.Include.NON_EMPTY
//})
public class Students {
	
	private String id;
	private String fName;
	private String lName;
	private String Address;
	private String Role;
	private Subjects subject;
	
	
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getRole() {
		return Role;
	}
	public void setRole(String role) {
		Role = role;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Subjects getSubject() {
		return subject;
	}
	public void setSubject(Subjects subject) {
		this.subject = subject;
	}
	
}
