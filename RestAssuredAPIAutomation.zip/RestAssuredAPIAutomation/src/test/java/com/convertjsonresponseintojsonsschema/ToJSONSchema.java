package com.convertjsonresponseintojsonsschema;

import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.jsonschema.JsonSchema;
import com.github.fge.jackson.JsonLoader;
import com.github.fge.jsonschema.main.JsonSchemaFactory;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.specification.RequestSpecification;

public class ToJSONSchema {
	 RestAssuredConfig config = RestAssured.config()
             .sslConfig(new SSLConfig().allowAllHostnames().relaxedHTTPSValidation());
 
	@Test
	public void getReq_01() {

	 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		 
     specBuilder.setBaseUri("https://reqres.in").setBasePath("/api/users").addQueryParam("page", "2");
	 RequestSpecification reqBuild = specBuilder.build();
	   
	 String response = RestAssured.
	             given()
	             .config(config)
	            .spec(reqBuild)
	            .when()
	            .get()
	            .then()
	            .log()
	            .all()
	            .extract()
	            .response()
	            .asPrettyString();
		
	 try {
		    JsonSchemaFactory factory = JsonSchemaFactory.byDefault();
		    JsonNode jsonNode = JsonLoader.fromString(response);
    com.github.fge.jsonschema.main.JsonSchema jsonSchema = factory.getJsonSchema(jsonNode);
		    com.github.fge.jsonschema.main.JsonSchema jsonSchemaString = jsonSchema;
		    	System.out.println(jsonSchemaString.toString());
		} catch (Exception e) {
		    e.printStackTrace();
		}

	}
}
