package com.pojo_jsonproprty_annotation;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Customer {
	/* used to map the properties name in the JSON and 
	the corresponding property in the java class | 
	used for both serialization and deserialization
	*/
	
	// json property name : customerID
	//class property name : id
	
	@JsonProperty("customerID")
	private String id;
	
	// json property name : customerID
	//class property name : id
		
	@JsonProperty("customerAddress")
	private String address;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
}
