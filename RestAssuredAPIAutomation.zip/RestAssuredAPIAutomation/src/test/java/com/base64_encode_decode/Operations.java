package com.base64_encode_decode;
import java.util.Base64;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.specification.RequestSpecification;

public class Operations<UrlEncodingUtils> {
	RestAssuredConfig config = RestAssured.config()
            .sslConfig(new SSLConfig().allowAllHostnames().relaxedHTTPSValidation());
	
    @Test
	public void operations() {
		
		
		// useful for encode and decode credentials in api operations
		
		//encode
		String originalString = "Hello, World!";
		System.out.println("Original string: " + originalString);
		String encodedString = Base64.getEncoder().encodeToString(originalString.getBytes());
		System.out.println("Encoded string: " + encodedString);
		
		
		//decode
	    String encodedStr = encodedString;
		byte[] decodedBytes = Base64.getDecoder().decode(encodedStr);
		String decodedString = new String(decodedBytes);
		System.out.println("Decoded string: " + decodedString);
			
	}	
	@Test
	public void test03() {
		  String userName = "postman" , password = "password";
		 String encodedBasicAuthCredentials = Base64.getEncoder().encodeToString((userName + ":" + password).getBytes());
		
		RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		specBuilder.setBaseUri("https://postman-echo.com") 
		           .setBasePath("/basic-auth")
		           .setConfig(config)
		           .addHeader("Authorization", "Basic " + encodedBasicAuthCredentials);
		RequestSpecification buildRequest = specBuilder.build();
		
		RestAssured.given()
		           .spec(buildRequest)
		           .log()
		           .all()
		           .when()
		           .get()
		           .then()
		           .log()
		           .all()
		           .extract()
		           .response()
		           .asPrettyString();
						
	}
}
