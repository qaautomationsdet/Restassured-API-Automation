package com.authentication;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BasicAuth {

	RestAssuredConfig config = RestAssured.config()
            .sslConfig(new SSLConfig().allowAllHostnames().relaxedHTTPSValidation());

  //@Test
	public void test01() { //non preemptive basic auth
		
		// base auth incode and decode using base64
		RequestSpecification  requestSpec = RestAssured.given();
		
		//https://postman-echo.com/basic-auth
		 requestSpec
		            .baseUri("https://postman-echo.com")
		            .basePath("/basic-auth")
		            .config(config);
		
		/* non preemptive basic auth = if the server will ask the credentials then only restassured will
		passes the credentials and non:premmetive is defaualt type */
		Response response = requestSpec.auth().basic(/*username*/"postman",/*password*/"password").get();
		
		System.out.println("Response status :" + response.statusLine());
	}
	//@Test
	public void test02() { //preemptive basic auth
		
		RequestSpecification  requestSpec = RestAssured.given();
		
		//https://postman-echo.com/basic-auth
		requestSpec.baseUri("https://postman-echo.com")
	    .basePath("/basic-auth")
		.config(config);
		
		// preemptive basic auth we are explicitly passess the auth credentials 
		// server withought asking any credentials , inbuilt the credentials with request and passing
		Response response = requestSpec.auth().preemptive().basic("postman","password").get();
		
		System.out.println("Response status :" + response.statusLine());
		
		
	}
	@Test
	public void test03() {
		
		String userName = "postman" , password = "password";
		  
		RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		specBuilder.setBaseUri("https://postman-echo.com") 
		           .setBasePath("/basic-auth")
		           .setConfig(config);
		          
		RequestSpecification buildRequest = specBuilder.build();
		buildRequest.auth()
		            .basic(userName,password);
	
		RestAssured.given()
		           .spec(buildRequest)
		           .log()
		           .all()
		           .when()
		           .get()
		           .then()
		           .log()
		           .all()
		           .extract()
		           .response()
		           .asPrettyString();
						
	}
}

