package com.apichainingin_diffclasess;
import org.json.simple.JSONObject;
import org.testng.ITestContext;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class Tc_03_UpdateUser {
	
	 RestAssuredConfig config = RestAssured.config()
             .sslConfig(new SSLConfig().allowAllHostnames().relaxedHTTPSValidation());
	
	@Test
	public void updateUser(ITestContext context) {
		
		System.out.println("*****************  UPDATE REQUEST ******************");
		
		
		int id = (Integer) context.getAttribute("user_id");
		
	    // Faker is depedency required inPOM.xml we can gerenate automatic data using diff methods
		Faker faker = new Faker();
			
		
		// for this JSONObject class required // json-simple // dependency in POM.xml
		JSONObject payload = new JSONObject();
		payload.put("name",faker.name().fullName());
		payload.put("gender","female");
		payload.put("email",faker.internet().emailAddress());
		payload.put("status","inactive");
		
		String bearerToken = "Bearer "+" 4488a6386727c443b96ef8c05aa44c1049589de7de1e71f2a3787544696d1bb7";
		

		RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		
		specBuilder.setBaseUri("https://gorest.co.in")
	               .setBasePath("/public/v2/users/"+id)
		           .addHeader("Authorization",bearerToken)
		           .setContentType(ContentType.JSON)
		           .setBody(payload.toJSONString())
		           .setConfig(config);
		            
				
		RequestSpecification requestBuild = specBuilder.build();
		
									     Response reponse = RestAssured.given()
												           .spec(requestBuild)
												           .log()
												           .all()
												           .when()
												           .put();
									                        
          ValidatableResponse validatableResponse = reponse.then();
                 
                  String responseBody = validatableResponse.log()
												           .all()
												           .extract()
												           .response()
												           .asPrettyString();
												
                                        // validation expeceted response
                                        validatableResponse.statusCode(200);
                                                       
                  JsonPath jsonPath = new JsonPath(responseBody);        
		
	}
}
