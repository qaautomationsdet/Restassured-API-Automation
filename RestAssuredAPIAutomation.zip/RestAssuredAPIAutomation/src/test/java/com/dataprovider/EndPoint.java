package com.dataprovider;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class EndPoint {
	
	 RestAssuredConfig config = RestAssured.config()
             .sslConfig(new SSLConfig().allowAllHostnames().relaxedHTTPSValidation());

	 @DataProvider(name = "getDataProvider")
	public Object[]endPoints(){
		
		return new Object[]{3,4,5,6   /*these values acts as endpoints*/ };
	}
	 
	// execute this test 4 times with 4 different end-points
    @Test(dataProvider = "getDataProvider")
	public void getRequest_01(int id) {
	
		 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		 
	     
		 specBuilder.setBaseUri("https://reqres.in").setBasePath("/api/users").addQueryParam("page",id);

		 RequestSpecification reqBuild = specBuilder.build();
		   
					 Response response = RestAssured.
										             given()
										            .config(config)
										            .spec(reqBuild)
										            .log()
										            .all()
										            .when()
										            .get();
	   ValidatableResponse validatbleRes = response .then();
								            								            		 
		        String extarctRes = validatbleRes   .log()
										            .all()
										            .extract()
										            .response()
										            .asPrettyString();
						            
		                              validatbleRes.assertThat()
		                                            .statusCode(200)
		                                            .statusLine("HTTP/1.1 200 OK");
		                                                                                     
	}

}
