package com.authentication;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BearerToken {

	RestAssuredConfig config = RestAssured.config()
            .sslConfig(new SSLConfig().allowAllHostnames().relaxedHTTPSValidation());

	@Test
	public void Req_02() {
	    //https://gorest.co.in/public/v2/users
		RequestSpecification requestSpec = RestAssured.given();
		
		requestSpec.baseUri("https://gorest.co.in")
		.basePath("/public/v2/users")
		.config(config)
		.auth().oauth2("token");
		
		JSONObject payload = new JSONObject();
		payload.put("name", "jhon");
		payload.put("gender","male");
		payload.put("email", "jhon@1234.com");
		payload.put("status", "Active");
		
		// suffix space is required after Bearer keyword ex. "Bearer "
		String Token = "Bearer af3658f9768e463";
		              
		requestSpec.header("Authorization",Token).
	    contentType(ContentType.JSON).
	    body(payload.toJSONString());
		
		Response response = requestSpec.post();
		
		System.out.println("response status line:" + response.statusLine());
		System.out.println(response.body().asString());
		
	}	
}
