package com.serialization_deserialization_concept;
import org.testng.annotations.Test;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Operations {

	//https://reqres.in/api/users?page=2
	
	/*
	 {
    "name": "morpheus",
    "job": "leader"
}
	 */
	@Test
	public void Serialization() throws JsonProcessingException {
		
		DataPojo dpojo = new DataPojo();
		dpojo.setName("jhon");
		dpojo.setJob("tester");
		
		ObjectMapper objmapper = new ObjectMapper();
		//converting java class object into json payload string
		String	 data = objmapper.writeValueAsString(dpojo);
		// data variable we will use as a payload
		System.out.println(data);

	}
	//@Test
	public void Deserialization() throws JsonProcessingException {
		
		DataPojo dpojo = new DataPojo();
		dpojo.setName("ram");
		dpojo.setJob("dev");
		
		ObjectMapper objmapper = new ObjectMapper();
		// consider dada as json response
		String	 data = objmapper.writeValueAsString(dpojo);
		
		
		DataPojo empObject = objmapper.readValue(data,DataPojo.class);
	
		System.out.println("firstname :"+empObject.getName());
		System.out.println("lastname :"+empObject.getJob());
	
	}
}
