package com.tostring_asstring_asprettystring_methods;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.specification.RequestSpecification;

public class Methods {

	 RestAssuredConfig config = RestAssured.config()
            .sslConfig(new SSLConfig().allowAllHostnames().relaxedHTTPSValidation());
	
	@Test(priority =1) //asString
	public void getReq_01() {
		
		
		 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		 
		  specBuilder.setBaseUri("https://reqres.in").setBasePath("/api/users").addQueryParam("page", "2");
    
		  RequestSpecification reqBuild = specBuilder.build();
		   
	String response = RestAssured.
		             given()
		            .spec(reqBuild)
		            .config(config)
		            .when()
		            .get()
		            .then()
		            .log()
		            .all()
		            .extract()
		            .response()
		            .asString();
		 
	//Get the body as a string.
	 System.err.println("Response asString  :"+response);
	
	
	}
	@Test(priority =2) //asPrettyString
		public void getReq_02() {
		
		
			 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
			 
			  specBuilder.setBaseUri("https://reqres.in").setBasePath("/api/users").addQueryParam("page", "2");
	     
			  RequestSpecification reqBuild = specBuilder.build();
			   
		String response = RestAssured.
			             given()
			            .spec(reqBuild)
			            .config(config)
			            .when()
			            .get()
			            .then()
			            .log()
			            .all()
			            .extract()
			            .response()
			            .asPrettyString();
			 
		//Get the body as a pretty formatted string.
		 System.err.println("Response asPrettyString  :"+response);
		
		
		}
	@Test(priority =3) //asPrettyString
	public void getReq_03() {
	
	
		 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		 
		  specBuilder.setBaseUri("https://reqres.in").setBasePath("/api/users").addQueryParam("page", "2");
     
		  RequestSpecification reqBuild = specBuilder.build();
		   
	String response = RestAssured.
		             given()
		            .spec(reqBuild)
		            .config(config)
		            .when()
		            .get()
		            .then()
		            .log()
		            .all()
		            .extract()
		            .response()
		            .toString();
		 
	//Returns a string representation of the object
	 System.err.println("Response toString  :"+response);
	
}
}