package com.authentication;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.authentication.OAuthSignature;
import io.restassured.http.Method;
import io.restassured.response.Response;

public class Oauth1_0 {
@Test
public void OauthRequest() {
	// Set up OAuth parameters
	String consumerKey = "your_consumer_key";
	String consumerSecret = "your_consumer_secret";
	String accessToken = "your_access_token";
	String accessSecret = "your_access_secret";

	// Send an HTTP request with OAuth authentication
Response response = 
			
        RestAssured
            .given()
	        .auth()
	        .oauth(consumerKey, consumerSecret, accessToken, accessSecret, OAuthSignature.HEADER)
	        .when()
	        .request(Method.GET, "/my/api/endpoint");

	// Assert the status code of the response
	response.then().statusCode(200);
	
	/*In this example, we set up the OAuth parameters consumerKey, consumerSecret, accessToken, and accessSecret.
	  We then use the RestAssured.given() method to start building an HTTP request, and use the auth() method to specify that we want to use OAuth authentication.

	We pass the OAuth parameters to the oauth() method, along with the OAuthSignature.
	HEADER option to specify that we want to use the OAuth signature in the HTTP header.

	Finally, we use the when() method to specify the HTTP method and endpoint for the request, and send the request using the request() method.
	 We then assert the status code of the response using the then() method.

	Note that OAuth 1.0 authentication requires generating a signature for the HTTP request using the OAuth parameters and including this signature in the HTTP request.
	 REST Assured's oauth() method takes care of generating the signature for you based on the provided */

 }
}
