package com.Serialization_And_Deserilization;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class Serialization {

	Student s1 = new Student();
	
public static void main(String[] args) {
	
	Student s1 = new Student();
	s1.studentName = "Prakash";
	s1.stuRollNO = 23;
	
	String str = "C:\\Users\\DELL\\eclipse-workspace-1\\RestAssuredAPIAutomation\\Src_dataFile.txt";
	
	try {
		
		FileOutputStream fos = new FileOutputStream(str);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(s1);
		oos.close();
		fos.close();
		
		System.out.println("Object saved in the file");
	}catch(Exception e) {
		e.printStackTrace();
	}
  }
}
