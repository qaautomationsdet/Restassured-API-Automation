package com.authentication;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class ApiKey {

	 RestAssuredConfig config = RestAssured.config()
             .sslConfig(new SSLConfig().allowAllHostnames().relaxedHTTPSValidation());
	
	//https://api.openweathermap.org/data/2.5/weather?q={city name}&appid={APIkey}
	
	String ExpectHoleResponseType_JsonObject = "";  
	String ExpectHoleResponseType_JSONArray = "";
	
	
	@Test 
	public void apikey() {
		RequestSpecification requestSpec = RestAssured.given();
		requestSpec.baseUri("https://api.openweathermap.org")
	    .basePath("/data/2.5/weather")
		.queryParam("q","delhi")
		.queryParam("appkey","2f752103556457524c30fb55b6ebae1d0")
		.config(config);
	
		Response response = requestSpec.get();		
		System.out.println(response.statusLine());
		
	}
	@Test
	public void apiKey1() {
	        
		
		String apiKey = "appkey";
		String apiValue ="2f752103556457524c30fb55b6ebae1d0";
		
		RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		
		specBuilder
		          .setBaseUri("https://api.openweathermap.org")
		          .setBasePath("/data/2.5/weather")
		          .addQueryParam("q","delhi")
		          .addQueryParam(apiKey,apiValue)
		          .setContentType(ContentType.JSON)
		          .setConfig(config);
		
   RequestSpecification buildRequest = specBuilder.build();
		
   // given inputs
   Response response = RestAssured.given()
		                                               .spec(buildRequest)
									                   .log()
									                   .all()
						  // action	get	                   
									                   .when()
									                   .get();
		                   
                          // get rsponse
  ValidatableResponse validatableResponse = response.then();								                  
       String responseBody = validatableResponse.log()
									            .all()
						                        .extract()
						                        .response()
						                        .asPrettyString();
						
          
              // validate response points   
                      validatableResponse.statusCode(200)
                                         .statusLine("HTTP/1.1 200 OK")
                                         .contentType(ContentType.JSON)   // validate response content type
                                         .body( ExpectHoleResponseType_JsonObject,Matchers.instanceOf(Map.class))// validate hole response body is json object or json array... 
                                         .time(Matchers.lessThan(9000L)); //response time expect less than 9 seconds                                        
		                                                                  //  1 second = 1000 milliseconds
                              
                // validate actual response body                              
                  JsonPath path = new JsonPath(responseBody);
                                                         
	}
}
