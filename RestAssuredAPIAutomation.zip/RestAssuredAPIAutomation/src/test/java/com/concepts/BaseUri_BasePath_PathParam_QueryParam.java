package com.concepts;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class BaseUri_BasePath_PathParam_QueryParam {
	
	//@Test
	public void get_01() {
		
		/* path param , query param
		 
		 path param query param increses redability , reusability of the url and restassured provides methods to 
		 create pathpraman and query param see below requests
		 */
		
		// query param [key = value] query 
		// query param is used the search or filter the resource
		// query param starts with   ?(que mark)   |   Example. https://reqres.in/api/users?page=2
		// combine to query parmas using &(and symbol)in postman
		

		 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		                          //https://reqres.in/api/users?page=2
		                         // base uri               //base path             // queryprarameter
		 specBuilder.setBaseUri("https://reqres.in").setBasePath("/api/users").addQueryParam(/*key*/"page",/*value*/"2");
		                                                                                  
		  RequestSpecification reqBuild = specBuilder.build();
		   
					 Response response = RestAssured.
										             given()
										            .spec(reqBuild)
										            .log()
										            .all()
										            .when()
										            .get();
	   ValidatableResponse validatbleRes = response .then();
								            		
								            	   		 
		        String extarctRes = validatbleRes   .log()
										            .all()
										            .extract()
										            .response()
										            .asPrettyString();
					
		            
		                              validatbleRes.assertThat()
		                                            .statusCode(200)
		                                            .statusLine("HTTP/1.1 200 OK");
		                                            
	}
	 
	//@Test
	public void get_02() {
		
		 RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		 
		                                    // base uri                          base path
		 specBuilder.setBaseUri("https://restful-booker.herokuapp.com").setBasePath("/booking");
		             
		  RequestSpecification reqBuild = specBuilder.build();
		   
					 Response response = RestAssured.
										             given()
										            .log()
											         .all()
										            .spec(reqBuild)
										            .when()
										            .get();
										         
	   ValidatableResponse validatbleRes = response .then();
								          							            		 
		        String extarctRes = validatbleRes   .log()
										            .all()
										            .extract()
										            .response()
										            .asPrettyString();
					
		                              validatbleRes
		                                            .statusCode(200)
		                                            .statusLine("HTTP/1.1 200 OK");
		                              		         
		                    
		                          	                                
	}
	
	@Test
	public void getReq() {
		
		// https://reqres.in/api/users/2
		RequestSpecBuilder specBuilder = new RequestSpecBuilder();
		
		// path param is not key value pair is like variable
		//Specify a path parameter. Path parameters are used to improve readability of the request path.
		// path param used to rooting the resouce
		// path param starts with  / (forwordslash)
		
		//https://reqres.in/api/users/2
		// id variable store 2
		int idValue = 2;
		                       // base uri                 //base path                  // path param
		specBuilder.setBaseUri("https://reqres.in").setBasePath("/api/users/{id}").addPathParam("id", idValue);
		specBuilder.setBaseUri("https://reqres.in").setBasePath("{id").addPathParam("id", specBuilder);      
		         
		 RequestSpecification reqBuild = specBuilder.build();
		   
		 Response response = RestAssured.
							             given()
							             .log()
								         .all()
							            .spec(reqBuild)
							            .when()
							            .get();
							         
ValidatableResponse validatbleRes = response .then();
					          							            		 
    String extarctRes = validatbleRes   .log()
							            .all()
							            .extract()
							            .response()
							            .asPrettyString();
		
                          validatbleRes
                                        .statusCode(200)
                                        .statusLine("HTTP/1.1 200 OK");
                          		         
		
	}
}
